# Case 001 — TTOP & Run Creation: ALCS G7 (Kirby vs. Bieber)

**Game:** Mariners @ Blue Jays — **ALCS Game 7**, 2025-10-20 (Toronto)  
**Pitchers:** SEA RHP **George Kirby** vs TOR RHP **Shane Bieber**

## Question
Does the **2nd/3rd time through the order (TTOP)** change **contact quality** and **run creation** for either side in this game?

## Hypotheses
- H1: On the 2nd look, hitter **hard-hit% (95+ mph)** increases vs. at least one starter.  
- H2: The starter who **fails to adjust pitch mix/lanes** shows a jump in xwOBA allowed and concedes the pivotal inning.  
- H3: The **highest-WPA plate appearance** is preceded by a pitch-mix or location shift that we can visualize.

## Data (Statcast)
- **Source:** Public Statcast (batter-by-batter & pitch-by-pitch).  
- **How to fetch:** See `notebooks/01_fetch_data.ipynb` (two options: pybaseball, or export CSV manually and drop into `data/raw/`).  
- **Note:** Do **not** commit large raw files or copyrighted video.

## Methods
Python (pandas, numpy, matplotlib). Metrics:
- **FP%** (first-pitch strike rate)
- **Hard-hit%** (exit velocity ≥ 95 mph)
- **RISP outcomes** (AB/H)
- **TTOP splits** (1st/2nd/3rd time through)
- **WPA/leverage context** (simple approximation if full play-by-play WPA is not available)

## Reproduce
```bash
conda env create -f environment.yml
conda activate sclab
pip install -e ../spraychartlab-utils   # your shared helpers
jupyter lab
```
Run notebooks in order: `01_` → `02_` → `03_`.  
Export key charts to `figures/`, then paste them into `report.md` and this README.

## Expected Outputs
- `figures/ttop_hardhit.png` — hard-hit% by TTOP for both teams
- `figures/ttop_mix_shift.png` — pitch-mix delta (1st→2nd look) for each starter
- `figures/zone_change.png` — location heat maps by look
- `figures/risp_summary.png` — RISP AB/H with notes
- `docs/index.html` — HTML export of the final notebook (via GitHub Actions)

## TL;DR (fill after analysis)
- Hard-hit% on 2nd look: SEA __% (Δ __), TOR __% (Δ __).  
- Mix shift: Kirby __→__, Bieber __→__.  
- Highest leverage PA: Inning __, Batter __ vs Pitcher __ → Result __ (why it happened).

**Contact:** contact.spraychartlab@proton.me
