# Report — Case 001: TTOP & Run Creation

## Summary (≤150 words)
_Fill in after you run the notebooks. What changed on 2nd/3rd looks? Who adjusted?_

## Key Charts
- ![TTOP hard-hit](figures/ttop_hardhit.png)
- ![Mix shift](figures/ttop_mix_shift.png)
- ![Zone change](figures/zone_change.png)
- ![RISP summary](figures/risp_summary.png)

## Notes
- Data: public Statcast. No raw video redistributed.
- See notebooks for steps and assumptions.
